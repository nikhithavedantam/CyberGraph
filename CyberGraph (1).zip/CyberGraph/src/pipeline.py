"""
Reusable pipeline used by the Streamlit dashboard (main.py keeps its own CLI flow).
"""
import pandas as pd

from .graph_builder import build_ip_url_graph, build_ip_agent_graph, build_ip_similarity_graph
from .features import behaviour_features, graph_features, url_centrality
from .detection import detect, evaluate


def run(df: pd.DataFrame, sim_threshold=0.90, risk_threshold=0.5, contamination=0.15):
    has_truth = "label" in df.columns
    truth = df.groupby("ip").label.first() if has_truth else None

    G_bip = build_ip_url_graph(df)
    G_agent = build_ip_agent_graph(df)
    G_sim = build_ip_similarity_graph(df, threshold=sim_threshold)

    beh = behaviour_features(df)
    base = beh.join(graph_features(G_bip, G_sim, G_agent, beh.index))
    feat = detect(base, contamination=contamination, threshold=risk_threshold)
    urls = url_centrality(G_bip)

    res = dict(df=df, feat=feat, urls=urls, G_bip=G_bip, G_sim=G_sim, G_agent=G_agent,
               has_truth=has_truth, metrics=None, ablation=None)

    if has_truth:
        metrics, _ = evaluate(feat, truth)
        iso = feat.copy(); iso["is_threat"] = (iso.anomaly_score >= 0.5).astype(int)
        ng = base.copy(); ng["community_size"], ng["sim_degree"], ng["clustering"] = 1, 0, 0
        ng = detect(ng, contamination=contamination, threshold=risk_threshold)
        rows = {}
        for name, f in {"IsolationForest only": iso, "Rules w/o graph": ng, "Full graph-aware": feat}.items():
            m, _ = evaluate(f, truth)
            rows[name] = {k: m[k] for k in ("precision", "recall", "f1")}
        res["metrics"], res["ablation"] = metrics, pd.DataFrame(rows).T
    return res
