"""
Step 6 - Self-contained HTML report (images embedded as base64).
"""
import base64
from datetime import datetime
from pathlib import Path


def _img(path):
    b = base64.b64encode(Path(path).read_bytes()).decode()
    return f'<img src="data:image/png;base64,{b}" style="max-width:100%;border:1px solid #e5e7eb;border-radius:8px">'


def build_report(out_dir, stats, feat, url_tbl, ablation, community_tbl, metrics):
    out = Path(out_dir)
    top = feat.sort_values("risk_score", ascending=False).head(20)[
        ["predicted_type", "risk_score", "n_requests", "unique_urls", "err_rate", "community_id", "community_size"]].round(3)
    html = f"""<!doctype html><html><head><meta charset="utf-8"><title>CyberGraph Report</title>
<style>body{{font-family:Segoe UI,Arial,sans-serif;max-width:1100px;margin:30px auto;padding:0 16px;color:#111827}}
h1{{color:#0369a1}}h2{{border-bottom:2px solid #e5e7eb;padding-bottom:4px;margin-top:36px}}
table{{border-collapse:collapse;font-size:13px}}td,th{{border:1px solid #d1d5db;padding:4px 8px}}th{{background:#f3f4f6}}
.k{{display:inline-block;background:#f0f9ff;border:1px solid #bae6fd;border-radius:10px;padding:10px 18px;margin:4px}}
.k b{{font-size:22px;display:block;color:#0369a1}}</style></head><body>
<h1>CyberGraph: Intelligent Web Threat Analytics</h1>
<p>Generated {datetime.now():%Y-%m-%d %H:%M}. Course: Graph and Web Analytics.</p>
<div>
<span class="k"><b>{stats['requests']:,}</b>log requests</span>
<span class="k"><b>{stats['ips']}</b>unique IPs</span>
<span class="k"><b>{stats['edges']}</b>IP–URL edges</span>
<span class="k"><b>{stats['threat_ips']}</b>threat IPs flagged</span>
<span class="k"><b>{metrics['f1']:.2f}</b>F1 score</span></div>

<h2>1. Similarity graph & communities</h2>{_img(out/'01_similarity_graph.png')}
<p>Each node is an IP; edges join IPs with near-identical URL-request profiles (cosine ≥ 0.90).
Botnets, scanners and brute-forcers appear as dense clusters, which is a signal invisible when looking at one IP alone.</p>
{community_tbl.to_html(index=False)}

<h2>2. Bipartite IP↔URL graph</h2>{_img(out/'02_bipartite_graph.png')}

<h2>3. Most targeted URLs (graph centrality)</h2>{url_tbl.round(4).head(10).to_html(index=False)}

<h2>4. Top risky IPs</h2>{_img(out/'04_top_risk.png')}{top.to_html()}

<h2>5. Timeline</h2>{_img(out/'05_timeline.png')}

<h2>6. Degree distribution</h2>{_img(out/'03_degree_distribution.png')}

<h2>7. Evaluation</h2>
<p>Precision {metrics['precision']:.3f} · Recall {metrics['recall']:.3f} · F1 {metrics['f1']:.3f}</p>
{_img(out/'06_confusion.png')} {_img(out/'07_ablation.png')}
<p>{ablation.round(3).to_html()}</p>
<p><i>Note: data is synthetic with known ground truth; real logs will be noisier and thresholds need retuning.</i></p>
</body></html>"""
    (out / "report.html").write_text(html, encoding="utf-8")
