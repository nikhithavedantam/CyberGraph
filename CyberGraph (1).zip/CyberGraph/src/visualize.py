"""
Step 5 - Visualisations (saved as PNG into outputs/).
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd

COLORS = {"normal": "#9aa5b1", "scanner": "#f59e0b", "bruteforce": "#8b5cf6",
          "sqli": "#ef4444", "ddos": "#0ea5e9", "suspicious": "#ec4899"}


def _component_layout(H):
    """Place each connected component on its own ring so dense cliques stay readable."""
    comps = sorted(nx.connected_components(H), key=len, reverse=True)
    pos = {}
    for ci, comp in enumerate(comps):
        ang = 2 * np.pi * ci / max(len(comps), 1)
        centre = np.array([np.cos(ang), np.sin(ang)]) * (2.2 if len(comps) > 1 else 0)
        nodes = sorted(comp)
        r = 0.12 * np.sqrt(len(nodes)) + 0.05
        for k, n in enumerate(nodes):
            a = 2 * np.pi * k / len(nodes)
            pos[n] = centre + r * np.array([np.cos(a), np.sin(a)])
    return pos


def plot_similarity_graph(G_sim, feat, path):
    H = G_sim.subgraph([n for n in G_sim if G_sim.degree(n) > 0]).copy()
    pos = _component_layout(H)
    fig, ax = plt.subplots(figsize=(11, 8))
    nx.draw_networkx_edges(H, pos, alpha=0.15, width=0.6, ax=ax)
    for t, c in COLORS.items():
        nodes = [n for n in H if feat.loc[n, "predicted_type"] == t]
        if nodes:
            sizes = [80 + 200 * feat.loc[n, "risk_score"] for n in nodes]
            nx.draw_networkx_nodes(H, pos, nodelist=nodes, node_color=c, node_size=sizes,
                                   label=f"{t} ({len(nodes)})", ax=ax, edgecolors="white", linewidths=.5)
    ax.legend(loc="upper left", frameon=True)
    ax.set_title("IP behaviour-similarity graph  (colour = detected type, size = risk score)")
    ax.axis("off"); fig.tight_layout(); fig.savefig(path, dpi=140); plt.close(fig)


def plot_bipartite(G_bip, feat, path, top_ips=60):
    threats = feat[feat.is_threat == 1].sort_values("risk_score", ascending=False)
    normals = feat[feat.is_threat == 0].sample(15, random_state=1)
    ips = list(threats.head(top_ips).index) + list(normals.index)
    urls = {u for ip in ips for u in G_bip.neighbors(ip)}
    H = G_bip.subgraph(ips + list(urls)).copy()
    pos = nx.spring_layout(H, seed=5, k=0.5, iterations=150)
    fig, ax = plt.subplots(figsize=(12, 9))
    nx.draw_networkx_edges(H, pos, alpha=0.12, ax=ax)
    for t, c in COLORS.items():
        nodes = [n for n in H if n in feat.index and feat.loc[n, "predicted_type"] == t]
        if nodes:
            nx.draw_networkx_nodes(H, pos, nodelist=nodes, node_color=c, node_size=70, ax=ax, label=t)
    un = [n for n in H if n in urls]
    nx.draw_networkx_nodes(H, pos, nodelist=un, node_shape="s", node_color="#111827", node_size=110, ax=ax, label="URL")
    top = sorted(un, key=lambda u: -H.degree(u))[:10]
    nx.draw_networkx_labels(H, pos, {u: u[:22] for u in top}, font_size=7, ax=ax)
    ax.legend(loc="upper left"); ax.set_title("IP ↔ URL bipartite graph (top threats + sample of normal users)")
    ax.axis("off"); fig.tight_layout(); fig.savefig(path, dpi=140); plt.close(fig)


def plot_degree_distribution(G_bip, path):
    ips = [n for n, k in G_bip.nodes(data="kind") if k == "ip"]
    deg = np.array(sorted([G_bip.degree(i) for i in ips]))
    vals, cnt = np.unique(deg, return_counts=True)
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    ax.loglog(vals, cnt, "o-", color="#0ea5e9")
    ax.set_xlabel("distinct URLs visited by an IP (degree)"); ax.set_ylabel("number of IPs")
    ax.set_title("Degree distribution of IP nodes"); ax.grid(alpha=.3, which="both")
    fig.tight_layout(); fig.savefig(path, dpi=140); plt.close(fig)


def plot_top_risk(feat, path, n=15):
    top = feat.sort_values("risk_score", ascending=False).head(n)[::-1]
    fig, ax = plt.subplots(figsize=(8, 5.5))
    ax.barh(top.index, top.risk_score, color=[COLORS.get(t, "#999") for t in top.predicted_type])
    ax.set_xlabel("risk score"); ax.set_title(f"Top {n} riskiest IPs")
    handles = [plt.Rectangle((0, 0), 1, 1, color=c) for c in COLORS.values()]
    ax.legend(handles, COLORS.keys(), loc="lower right", fontsize=8)
    fig.tight_layout(); fig.savefig(path, dpi=140); plt.close(fig)


def plot_timeline(df, feat, path):
    d = df.copy()
    d["type"] = d.ip.map(feat.predicted_type)
    piv = d.groupby([pd.Grouper(key="timestamp", freq="15min"), "type"]).size().unstack(fill_value=0)
    fig, ax = plt.subplots(figsize=(11, 4.5))
    piv.plot.area(ax=ax, color=[COLORS.get(c, "#999") for c in piv.columns], alpha=.85, linewidth=0)
    ax.set_title("Traffic timeline by detected type (15-min bins)"); ax.set_ylabel("requests")
    fig.tight_layout(); fig.savefig(path, dpi=140); plt.close(fig)


def plot_confusion(cm, path):
    fig, ax = plt.subplots(figsize=(4.5, 4))
    ax.imshow(cm, cmap="Blues")
    for (i, j), v in np.ndenumerate(cm):
        ax.text(j, i, v, ha="center", va="center", fontsize=14, color="black")
    ax.set_xticks([0, 1], ["normal", "threat"]); ax.set_yticks([0, 1], ["normal", "threat"])
    ax.set_xlabel("predicted"); ax.set_ylabel("actual"); ax.set_title("Confusion matrix")
    fig.tight_layout(); fig.savefig(path, dpi=140); plt.close(fig)


def plot_ablation(ab, path):
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    x = np.arange(len(ab)); w = .27
    for k, (m, c) in enumerate(zip(["precision", "recall", "f1"], ["#0ea5e9", "#f59e0b", "#10b981"])):
        ax.bar(x + (k - 1) * w, ab[m], w, label=m, color=c)
    ax.set_xticks(x, ab.index, fontsize=8); ax.set_ylim(0, 1.05); ax.legend()
    ax.set_title("Does graph analytics help? (ablation)")
    fig.tight_layout(); fig.savefig(path, dpi=140); plt.close(fig)
