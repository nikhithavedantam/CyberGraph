"""
Step 2 - Graph construction.

Three graph views are built from the logs:

1. Heterogeneous bipartite graph  IP  --(requests)-->  URL
   edge weight = number of requests, edge attr 'errors' = 4xx/5xx count.
2. IP-agent graph (IP --uses--> User-Agent) to expose tool fingerprints
   shared by many IPs.
3. IP similarity graph (one-mode projection): two IPs are linked if their
   URL-request profiles are highly similar (cosine similarity). Botnets,
   scanners and brute-forcers form dense clusters here.
"""
import networkx as nx
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity


def build_ip_url_graph(df: pd.DataFrame) -> nx.Graph:
    G = nx.Graph()
    df = df.assign(is_err=(df.status >= 400).astype(int))
    agg = df.groupby(["ip", "url"]).agg(weight=("url", "size"), errors=("is_err", "sum")).reset_index()
    for ip in df.ip.unique():
        G.add_node(ip, kind="ip", bipartite=0)
    for url in df.url.unique():
        G.add_node(url, kind="url", bipartite=1)
    for r in agg.itertuples():
        G.add_edge(r.ip, r.url, weight=int(r.weight), errors=int(r.errors))
    return G


def build_ip_agent_graph(df: pd.DataFrame) -> nx.Graph:
    G = nx.Graph()
    for r in df.groupby(["ip", "user_agent"]).size().reset_index(name="w").itertuples():
        G.add_node(r.ip, kind="ip")
        G.add_node(r.user_agent, kind="agent")
        G.add_edge(r.ip, r.user_agent, weight=int(r.w))
    return G


def build_ip_similarity_graph(df: pd.DataFrame, threshold: float = 0.90, min_requests: int = 20) -> nx.Graph:
    """One-mode projection using cosine similarity of URL request vectors.

    Only IPs with >= min_requests are linked (very short sessions give noisy vectors).
    """
    counts = df.groupby("ip").size()
    active = counts[counts >= min_requests].index
    M = df[df.ip.isin(active)].pivot_table(index="ip", columns="url", values="method",
                                           aggfunc="count", fill_value=0)
    S = cosine_similarity(M.values)
    G = nx.Graph()
    G.add_nodes_from(df.ip.unique())
    ips = list(M.index)
    ii, jj = np.where(np.triu(S, k=1) >= threshold)
    for i, j in zip(ii, jj):
        G.add_edge(ips[i], ips[j], weight=float(S[i, j]))
    return G
