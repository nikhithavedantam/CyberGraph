"""
Step 4 - Threat detection.

Hybrid approach:
  * Unsupervised anomaly score  : Isolation Forest on behavioural + graph features
  * Rule / graph-context score  : interpretable indicators (payloads, auth failures,
                                  404 storms, botnet-community membership ...)
  * Risk score = weighted blend, then thresholded into a threat flag.
Attack type is assigned with transparent rules so results can be explained.
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (precision_score, recall_score, f1_score, confusion_matrix,
                             classification_report)

FEATURES = ["n_requests", "unique_urls", "url_entropy", "top_url_share", "err_rate", "rate_404",
            "auth_fail_rate", "post_ratio", "payload_ratio", "sensitive_ratio", "tool_agent",
            "peak_req_per_min", "median_gap", "degree_urls", "pagerank", "hub_score",
            "community_size", "sim_degree", "clustering", "agent_share"]


def _minmax(s):
    rng = s.max() - s.min()
    return (s - s.min()) / rng if rng else s * 0


def rule_score(f: pd.DataFrame) -> pd.Series:
    """0..1 interpretable score."""
    s = pd.DataFrame(index=f.index)
    s["payload"] = (f.payload_ratio > 0.15).astype(float)
    s["auth_brute"] = ((f.auth_fail_rate > 0.5) & (f.post_ratio > 0.5) & (f.n_requests > 30)).astype(float)
    s["scan"] = ((f.rate_404 > 0.4) & (f.unique_urls > 15)).astype(float) * 0.9 \
        + (f.sensitive_ratio > 0.5).astype(float) * 0.3
    # botnet: many near-identical IPs (graph community) hammering few URLs fast
    s["botnet"] = ((f.community_size >= 8) & (f.top_url_share > 0.8) & (f.peak_req_per_min > 25)).astype(float)
    s["tool"] = f.tool_agent * 0.25
    s["rate"] = (f.peak_req_per_min > 80).astype(float) * 0.2
    return s.sum(axis=1).clip(0, 1)


def classify_type(f: pd.DataFrame) -> pd.Series:
    out = []
    for r in f.itertuples():
        if r.payload_ratio > 0.15:
            out.append("sqli")
        elif r.auth_fail_rate > 0.5 and r.post_ratio > 0.5 and r.n_requests > 30:
            out.append("bruteforce")
        elif r.community_size >= 8 and r.top_url_share > 0.8 and r.peak_req_per_min > 25:
            out.append("ddos")
        elif r.rate_404 > 0.4 and r.unique_urls > 15:
            out.append("scanner")
        else:
            out.append("normal")
    return pd.Series(out, index=f.index)


def detect(feat: pd.DataFrame, contamination=0.15, threshold=0.5, seed=42):
    X = StandardScaler().fit_transform(np.log1p(feat[FEATURES].clip(lower=0)))
    iso = IsolationForest(n_estimators=300, contamination=contamination, random_state=seed).fit(X)
    feat = feat.copy()
    feat["anomaly_score"] = _minmax(pd.Series(-iso.score_samples(X), index=feat.index))
    feat["rule_score"] = rule_score(feat)
    feat["risk_score"] = 0.35 * feat.anomaly_score + 0.65 * feat.rule_score
    feat["predicted_type"] = classify_type(feat)
    feat["is_threat"] = ((feat.risk_score >= threshold) | (feat.predicted_type != "normal")).astype(int)
    feat.loc[(feat.is_threat == 1) & (feat.predicted_type == "normal"), "predicted_type"] = "suspicious"
    return feat


def evaluate(feat: pd.DataFrame, truth: pd.Series):
    y_true = (truth.reindex(feat.index) != "normal").astype(int)
    y_pred = feat.is_threat
    metrics = dict(precision=precision_score(y_true, y_pred), recall=recall_score(y_true, y_pred),
                   f1=f1_score(y_true, y_pred), confusion=confusion_matrix(y_true, y_pred))
    return metrics, y_true
