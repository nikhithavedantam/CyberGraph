"""
Step 3 - Graph analytics + behavioural feature engineering (one row per IP).
"""
import re
import numpy as np
import pandas as pd
import networkx as nx

PAYLOAD_RE = re.compile(r"(union\s+select|or\s+1=1|'\s*or\s*'|drop\s+table|<script|\.\./|sleep\(|/etc/passwd)", re.I)
TOOL_RE = re.compile(r"(sqlmap|nikto|hydra|masscan|curl|python-requests)", re.I)
SENSITIVE_RE = re.compile(r"(\.env|\.git|phpmyadmin|wp-login|backup|config\.php|passwd|\.htaccess|server-status|db\.sql|/admin|/console)", re.I)


def _entropy(counts):
    p = np.asarray(counts, float)
    p = p / p.sum()
    return float(-(p * np.log2(p)).sum())


def behaviour_features(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    d["is_err"] = d.status >= 400
    d["is_404"] = d.status == 404
    d["is_auth_fail"] = d.status.isin([401, 403])
    d["is_post"] = d.method == "POST"
    d["payload"] = d.url.apply(lambda u: bool(PAYLOAD_RE.search(u)))
    d["sensitive"] = d.url.apply(lambda u: bool(SENSITIVE_RE.search(u)))
    d["tool_ua"] = d.user_agent.apply(lambda u: bool(TOOL_RE.search(u)))
    d["minute"] = d.timestamp.dt.floor("min")

    rows = {}
    for ip, g in d.groupby("ip"):
        gaps = g.timestamp.sort_values().diff().dt.total_seconds().dropna()
        url_counts = g.url.value_counts()
        rows[ip] = dict(
            n_requests=len(g),
            unique_urls=g.url.nunique(),
            url_entropy=_entropy(url_counts.values),
            top_url_share=url_counts.iloc[0] / len(g),
            err_rate=g.is_err.mean(),
            rate_404=g.is_404.mean(),
            auth_fail_rate=g.is_auth_fail.mean(),
            post_ratio=g.is_post.mean(),
            payload_ratio=g.payload.mean(),
            sensitive_ratio=g.sensitive.mean(),
            tool_agent=float(g.tool_ua.any()),
            peak_req_per_min=g.groupby("minute").size().max(),
            median_gap=float(gaps.median()) if len(gaps) else 0.0,
        )
    return pd.DataFrame.from_dict(rows, orient="index")


def graph_features(G_bip: nx.Graph, G_sim: nx.Graph, G_agent: nx.Graph, ips) -> pd.DataFrame:
    """Centrality, community and neighbourhood features from the graphs."""
    pr = nx.pagerank(G_bip, weight="weight")
    hubs, auths = nx.hits(G_bip, max_iter=500, normalized=True)
    deg_w = dict(G_bip.degree(weight="weight"))
    deg = dict(G_bip.degree())

    # communities on the similarity graph (Louvain)
    comms = nx.community.louvain_communities(G_sim, weight="weight", seed=7)
    comm_of, comm_size = {}, {}
    for cid, c in enumerate(sorted(comms, key=len, reverse=True)):
        for n in c:
            comm_of[n] = cid
            comm_size[n] = len(c)

    clust = nx.clustering(G_sim, weight="weight")
    sim_deg = dict(G_sim.degree())
    # how many IPs share the same user-agent string?
    agent_pop = {a: G_agent.degree(a) for a, k in G_agent.nodes(data="kind") if k == "agent"}
    ip_agent_share = {}
    for ip in ips:
        ags = [n for n in G_agent.neighbors(ip)] if ip in G_agent else []
        ip_agent_share[ip] = max([agent_pop.get(a, 1) for a in ags], default=1)

    out = pd.DataFrame(index=list(ips))
    out["degree_urls"] = [deg.get(i, 0) for i in ips]
    out["weighted_degree"] = [deg_w.get(i, 0) for i in ips]
    out["pagerank"] = [pr.get(i, 0) for i in ips]
    out["hub_score"] = [hubs.get(i, 0) for i in ips]
    out["community_id"] = [comm_of.get(i, -1) for i in ips]
    out["community_size"] = [comm_size.get(i, 1) for i in ips]
    out["sim_degree"] = [sim_deg.get(i, 0) for i in ips]
    out["clustering"] = [clust.get(i, 0) for i in ips]
    out["agent_share"] = [ip_agent_share[i] for i in ips]
    return out


def url_centrality(G_bip: nx.Graph) -> pd.DataFrame:
    """Which URLs are the most attacked / central?"""
    urls = [n for n, k in G_bip.nodes(data="kind") if k == "url"]
    pr = nx.pagerank(G_bip, weight="weight")
    _, auth = nx.hits(G_bip, max_iter=500, normalized=True)
    bc = nx.betweenness_centrality(G_bip, weight=None, k=min(150, len(G_bip)), seed=1)
    rows = []
    for u in urls:
        errs = sum(a["errors"] for _, _, a in G_bip.edges(u, data=True))
        reqs = sum(a["weight"] for _, _, a in G_bip.edges(u, data=True))
        rows.append(dict(url=u, visitors=G_bip.degree(u), requests=reqs, error_requests=errs,
                         pagerank=pr[u], authority=auth[u], betweenness=bc[u]))
    return pd.DataFrame(rows).sort_values("pagerank", ascending=False).reset_index(drop=True)
