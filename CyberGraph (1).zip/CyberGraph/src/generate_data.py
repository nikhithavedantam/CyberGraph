"""
Step 1 - Synthetic web-server log generator.

Produces an access-log style dataset that mixes normal traffic with five
labelled behaviours, so the detection pipeline can be evaluated.

Behaviours
    scanner      : one IP probes many non-existent / sensitive URLs (lots of 404)
    bruteforce   : one IP hammers POST /login with 401 responses
    sqli         : one IP sends SQL-injection / XSS style payloads in URLs
    ddos         : a botnet of many IPs floods a single URL at high rate
    crawler      : aggressive but harmless bot (a deliberate "hard negative")
"""
import random
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

PAGES = ["/", "/home", "/products", "/products/1", "/products/2", "/products/3",
         "/cart", "/checkout", "/about", "/contact", "/blog", "/blog/post-1",
         "/blog/post-2", "/search", "/faq", "/profile", "/api/items", "/api/orders"]
SENSITIVE = ["/admin", "/admin/login", "/.env", "/.git/config", "/wp-login.php",
             "/phpmyadmin", "/backup.zip", "/config.php", "/server-status",
             "/etc/passwd", "/api/v1/users", "/console", "/db.sql", "/.htaccess"]
SQLI = ["/products?id=1' OR '1'='1", "/search?q=<script>alert(1)</script>",
        "/products?id=1 UNION SELECT username,password FROM users--",
        "/profile?id=1; DROP TABLE users--", "/search?q=../../etc/passwd",
        "/api/items?id=1' AND SLEEP(5)--", "/blog?p=1' OR 1=1--"]
AGENTS_NORMAL = ["Mozilla/5.0 (Windows NT 10.0) Chrome/120", "Mozilla/5.0 (Macintosh) Safari/17",
                 "Mozilla/5.0 (X11; Linux) Firefox/121", "Mozilla/5.0 (iPhone) Mobile Safari",
                 "Mozilla/5.0 (Android 13) Chrome Mobile"]
AGENTS_TOOLS = ["sqlmap/1.7", "Nikto/2.5", "python-requests/2.31", "curl/8.4", "Hydra/9.5", "masscan/1.3"]


def _ip(rng, prefix=None):
    if prefix:
        return f"{prefix}.{rng.randint(1, 254)}"
    return f"{rng.randint(11, 223)}.{rng.randint(0, 255)}.{rng.randint(0, 255)}.{rng.randint(1, 254)}"


def generate(n_normal=300, seed=42):
    rng = random.Random(seed)
    np.random.seed(seed)
    start = datetime(2026, 9, 1, 0, 0, 0)
    rows = []

    def add(ip, t, method, url, status, ua, label):
        rows.append(dict(timestamp=t, ip=ip, method=method, url=url,
                         status=status, user_agent=ua, label=label))

    # normal users
    for _ in range(n_normal):
        ip, ua = _ip(rng), rng.choice(AGENTS_NORMAL)
        t = start + timedelta(seconds=rng.randint(0, 86000))
        for _ in range(rng.randint(3, 25)):
            t += timedelta(seconds=rng.randint(3, 120))
            url = rng.choice(PAGES)
            status = rng.choices([200, 304, 404, 500], [88, 6, 4, 2])[0]
            method = "POST" if url in ("/checkout", "/search") and rng.random() < .4 else "GET"
            add(ip, t, method, url, status, ua, "normal")

    # scanners
    for _ in range(6):
        ip, ua = _ip(rng, "185.220.101"), rng.choice(AGENTS_TOOLS)
        t = start + timedelta(seconds=rng.randint(0, 80000))
        for _ in range(rng.randint(80, 160)):
            t += timedelta(seconds=rng.uniform(0.1, 1.5))
            url = rng.choice(SENSITIVE + [f"/{rng.choice('abcdefgh')}{rng.randint(1,999)}" for _ in range(4)])
            add(ip, t, "GET", url, rng.choices([404, 403, 200], [80, 15, 5])[0], ua, "scanner")

    # brute force
    for _ in range(5):
        ip, ua = _ip(rng, "45.155.205"), rng.choice(["Hydra/9.5", "python-requests/2.31"])
        t = start + timedelta(seconds=rng.randint(0, 80000))
        for _ in range(rng.randint(120, 250)):
            t += timedelta(seconds=rng.uniform(0.2, 2))
            add(ip, t, "POST", rng.choice(["/login", "/admin/login", "/wp-login.php"]),
                rng.choices([401, 403, 200], [92, 6, 2])[0], ua, "bruteforce")

    # SQLi / XSS
    for _ in range(5):
        ip, ua = _ip(rng, "91.240.118"), rng.choice(["sqlmap/1.7", "curl/8.4"])
        t = start + timedelta(seconds=rng.randint(0, 80000))
        for _ in range(rng.randint(30, 70)):
            t += timedelta(seconds=rng.uniform(0.5, 6))
            add(ip, t, "GET", rng.choice(SQLI), rng.choices([500, 400, 200], [55, 35, 10])[0], ua, "sqli")

    # DDoS botnet on ONE target
    target = "/api/orders"
    burst = start + timedelta(hours=14)
    for _ in range(40):
        ip, ua = _ip(rng), rng.choice(AGENTS_TOOLS[2:4])
        t = burst + timedelta(seconds=rng.randint(0, 60))
        for _ in range(rng.randint(40, 80)):
            t += timedelta(seconds=rng.uniform(0.05, 0.6))
            add(ip, t, "GET", target, rng.choices([200, 503, 429], [30, 50, 20])[0], ua, "ddos")

    # benign aggressive crawlers (hard negatives)
    for _ in range(4):
        ip, ua = _ip(rng, "66.249.66"), "Googlebot/2.1 (+http://www.google.com/bot.html)"
        t = start + timedelta(seconds=rng.randint(0, 40000))
        for _ in range(rng.randint(60, 120)):
            t += timedelta(seconds=rng.uniform(1, 8))
            add(ip, t, "GET", rng.choice(PAGES), rng.choices([200, 304], [85, 15])[0], ua, "normal")

    return pd.DataFrame(rows).sort_values("timestamp").reset_index(drop=True)


if __name__ == "__main__":
    d = generate()
    d.to_csv("data/web_logs.csv", index=False)
    print(d.label.value_counts())
